#include "VulkanQueue.h"
#include "VulkanDevice.h"

namespace lava
{
  VulkanQueue::VulkanQueue( VulkanDevice& device, vk::Queue queue,
    GpuQueueType type, uint32_t index )
    : _device( device )
    , _queue( queue )
    , _type( type )
    , _index( index )
  { }

  VulkanQueue::~VulkanQueue( void )
  {
  }

  void VulkanQueue::waitIdle( void ) const
  {
	  _queue.waitIdle( );
  }
}
